/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	config.uiColor = '#AADC6E';
	
	config.language =  "zh-cn" ; 
	config.toolbar = 'Full';
    config.height = 300;
//    config.width = 1000;
    config.image_previewText = " ";

	config.toolbarGroups = [
		{ name: 'clipboard',   groups: [ 'clipboard', 'undo' ] },
//		{ name: 'editing',     groups: [ 'find', 'selection', 'spellchecker' ] },
		{ name: 'links' },
		{ name: 'insert' },
//		{ name: 'forms' },
		{ name: 'tools' },
		{ name: 'document',	   groups: [ 'mode', 'document', 'doctools' ] },
		{ name: 'others' },
		{ name: 'colors' },
		'/',
		{ name: 'basicstyles', groups: [ 'basicstyles', 'cleanup' ] },
		{ name: 'paragraph',   groups: [ 'list', 'indent', 'blocks', 'align', 'bidi' ] },
		{ name: 'styles' },
//		{ name: 'colors' },
//		{ name: 'about' }
	];
	
	// Remove some buttons provided by the standard plugins, which are
	// not needed in the Standard(s) toolbar.
	config.removeButtons ='Underline,Subscript,Superscript';
	// Set the most common block elements.
	config.format_tags ='p;h1;h2;h3;pre';
	// Simplify the dialog windows.
	config.removeDialogTabs ='image:advanced;link:advanced';
	//CKFinder的引入配置
	config.filebrowserBrowseUrl ='/CKEditorPractice06/Addons/ckfinder/ckfinder.html' ;  
	config.filebrowserImageBrowseUrl ='/CKEditorPractice06/Addons/ckfinder/ckfinder.html?type=Images' ;  
	config.filebrowserFlashBrowseUrl ='/CKEditorPractice06/Addons/ckfinder/ckfinder.html?type=Flash' ;  
	config.filebrowserUploadUrl ='/CKEditorPractice06/Addons/ckfinder/core/connector/java/connector.java?command=QuickUpload&type=Files' ;  
	config.filebrowserImageUploadUrl ='/CKEditorPractice06/Addons/ckfinder/core/connector/java/connector.java?command=QuickUpload&type=Images' ;  
	config.filebrowserFlashUploadUrl ='/CKEditorPractice06/Addons/ckfinder/core/connector/java/connector.java?command=QuickUpload&type=Flash' ;  
	config.filebrowserWindowWidth ='800';  
	config.filebrowserWindowHeight ='500';  
	config.language ="zh-cn" ;  

};
